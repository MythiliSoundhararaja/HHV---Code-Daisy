// Supabase Edge Function for the Medical Assistant/Chatbot

import { createClient } from "npm:@supabase/supabase-js@2.39.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

Deno.serve(async (req: Request) => {
  // Handle CORS preflight request
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    // Create Supabase client with service role key
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Parse request body
    const { message, userId } = await req.json();

    if (!message || !userId) {
      throw new Error("Message and userId are required");
    }

    // Generate response based on user's message
    const response = generateResponse(message);
    
    // In a real implementation, this would call an AI model API
    // const response = await callAIModel(message);

    // Save message to database
    const { error } = await supabaseClient
      .from("chat_messages")
      .insert([
        {
          user_id: userId,
          message: message,
          response: response,
          is_ai: true,
        },
      ]);

    if (error) throw error;

    return new Response(
      JSON.stringify({ 
        success: true, 
        response 
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});

// Simple response generation (in a real app, this would be replaced with a call to an AI model)
function generateResponse(message: string): string {
  const messageLC = message.toLowerCase();
  
  if (messageLC.includes("appointment") || messageLC.includes("schedule")) {
    return "I'd be happy to help you schedule an appointment. What type of doctor would you like to see, and what's your preferred date and time?";
  } else if (messageLC.includes("medication") || messageLC.includes("medicine")) {
    return "It's important to take your medications as prescribed. I can set up reminders for you. What medications are you currently taking?";
  } else if (messageLC.includes("symptom") || messageLC.includes("pain") || messageLC.includes("feeling")) {
    return "I'm sorry to hear you're not feeling well. Please describe your symptoms in detail so I can provide better guidance. However, for urgent medical concerns, please contact your doctor directly.";
  } else if (messageLC.includes("thank")) {
    return "You're welcome! I'm here to help with any other health questions you might have.";
  } else if (messageLC.includes("hello") || messageLC.includes("hi")) {
    return "Hello! I'm your healthcare assistant. How can I help you today?";
  } else {
    return "I'm here to assist with your healthcare needs. I can help schedule appointments, remind you about medications, or answer general health questions. How can I help you today?";
  }
}