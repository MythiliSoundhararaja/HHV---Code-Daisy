import React, { useState, useRef } from 'react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { File, Upload, FileText, Plus, X, FileImage } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { useAuthStore } from '../../lib/auth';
import { supabase } from '../../lib/supabase';

// For demonstration purposes - in real app would integrate with OCR service
const mockOcrProcessing = async (file: File): Promise<string> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(`This is a sample OCR extracted text from ${file.name}. 
      In a real application, this would contain actual text extracted from the document using Tesseract.js or another OCR service.
      
      Patient: John Doe
      Date: 2025-05-15
      Doctor: Dr. Smith
      
      Blood Pressure: 120/80 mmHg
      Heart Rate: 72 bpm
      Temperature: 98.6°F
      
      Assessment: Patient is in good health. Regular follow-up recommended in 6 months.`);
    }, 2000);
  });
};

// Mock AI summary processing
const mockAiSummarization = async (text: string): Promise<string> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(`Summary: Routine check-up report shows normal vital signs. Patient is in good health with no concerning issues. Follow-up recommended in 6 months.`);
    }, 1500);
  });
};

export const DocumentUploader: React.FC = () => {
  const [files, setFiles] = useState<File[]>([]);
  const [dragActive, setDragActive] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [processingStep, setProcessingStep] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { user } = useAuthStore();
  
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const newFiles = Array.from(e.dataTransfer.files).filter(
        file => file.type === 'application/pdf' || file.type.startsWith('image/')
      );
      
      if (newFiles.length === 0) {
        toast.error('Only PDF and image files are supported');
        return;
      }
      
      setFiles(prev => [...prev, ...newFiles]);
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files).filter(
        file => file.type === 'application/pdf' || file.type.startsWith('image/')
      );
      
      if (newFiles.length === 0) {
        toast.error('Only PDF and image files are supported');
        return;
      }
      
      setFiles(prev => [...prev, ...newFiles]);
    }
  };
  
  const removeFile = (indexToRemove: number) => {
    setFiles(files.filter((_, index) => index !== indexToRemove));
  };
  
  const uploadFiles = async () => {
    if (!user || files.length === 0) return;
    
    setIsUploading(true);
    setUploadProgress(0);
    
    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = `${user.id}/${fileName}`;
        
        // Upload progress simulation
        const progressInterval = setInterval(() => {
          setUploadProgress(prev => {
            const newProgress = prev + Math.random() * 10;
            return newProgress >= 100 ? 100 : newProgress;
          });
        }, 200);
        
        setProcessingStep('Uploading file to secure storage...');
        
        // In a real app, upload to Supabase Storage
        // const { error: uploadError } = await supabase.storage
        //  .from('medical-documents')
        //  .upload(filePath, file);
        
        // if (uploadError) throw uploadError;
        
        // Wait for "upload" to complete
        await new Promise(resolve => setTimeout(resolve, 1500));
        clearInterval(progressInterval);
        setUploadProgress(100);
        
        setProcessingStep('Extracting text with OCR...');
        const extractedText = await mockOcrProcessing(file);
        
        setProcessingStep('Generating AI summary...');
        const summary = await mockAiSummarization(extractedText);
        
        setProcessingStep('Saving to database...');
        
        // In a real app, store in Supabase database
        // const { error: dbError } = await supabase
        //   .from('medical_reports')
        //   .insert({
        //     user_id: user.id,
        //     file_name: file.name,
        //     file_url: filePath,
        //     extracted_text: extractedText,
        //     summary: summary,
        //     report_date: new Date().toISOString(),
        //     report_type: file.type.includes('pdf') ? 'PDF Document' : 'Image'
        //   });
        
        // if (dbError) throw dbError;
        
        // Simulate DB save
        await new Promise(resolve => setTimeout(resolve, 500));
      }
      
      toast.success(`Successfully processed ${files.length} document${files.length > 1 ? 's' : ''}`);
      setFiles([]);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to process documents';
      toast.error(errorMessage);
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
      setProcessingStep(null);
    }
  };
  
  return (
    <Card>
      <div className="p-4">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Upload Medical Documents</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
          Upload medical reports, lab results, or prescriptions. We'll extract the text and generate a summary.
        </p>
        
        <div
          className={`
            border-2 border-dashed rounded-lg p-6 
            ${dragActive ? 'border-cyan-500 bg-cyan-50 dark:bg-cyan-900/20' : 'border-gray-300 dark:border-gray-700'} 
            transition-colors duration-200 text-center
          `}
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
        >
          <input
            type="file"
            id="file-upload"
            multiple
            className="hidden"
            accept="application/pdf,image/*"
            onChange={handleFileChange}
            ref={fileInputRef}
            disabled={isUploading}
          />
          
          <div className="flex flex-col items-center justify-center">
            <Upload size={36} className={`${dragActive ? 'text-cyan-500' : 'text-gray-400'} mb-2`} />
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {dragActive ? 'Drop files here' : 'Drag and drop files here'}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
              Supported formats: PDF, JPEG, PNG
            </p>
            <Button
              size="sm"
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              leftIcon={<Plus size={16} />}
            >
              Browse Files
            </Button>
          </div>
        </div>
        
        {files.length > 0 && (
          <>
            <div className="mt-4">
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Selected Files ({files.length})
              </h4>
              <ul className="space-y-2">
                {files.map((file, index) => (
                  <li key={index} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded-md">
                    <div className="flex items-center overflow-hidden">
                      {file.type === 'application/pdf' ? (
                        <FileText size={20} className="text-red-500 mr-2 flex-shrink-0" />
                      ) : (
                        <FileImage size={20} className="text-blue-500 mr-2 flex-shrink-0" />
                      )}
                      <span className="text-sm text-gray-700 dark:text-gray-300 truncate">
                        {file.name}
                      </span>
                    </div>
                    <button 
                      className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                      onClick={() => removeFile(index)}
                      disabled={isUploading}
                      aria-label="Remove file"
                    >
                      <X size={16} />
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            
            {isUploading ? (
              <div className="mt-4">
                <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">{processingStep}</p>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-2">
                  <div
                    className="bg-cyan-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  ></div>
                </div>
              </div>
            ) : (
              <Button
                className="mt-4 w-full"
                onClick={uploadFiles}
                leftIcon={<Upload size={16} />}
              >
                Upload and Process {files.length} File{files.length > 1 ? 's' : ''}
              </Button>
            )}
          </>
        )}
      </div>
    </Card>
  );
};