import React, { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { FileText, FileImage, Download, X, BarChart, ChevronLeft, ChevronRight } from 'lucide-react';
import { MedicalReport } from '../../lib/supabase';

interface ReportViewerProps {
  report: MedicalReport | null;
  onClose: () => void;
}

export const ReportViewer: React.FC<ReportViewerProps> = ({ report, onClose }) => {
  const [tab, setTab] = useState<'summary' | 'full'>('summary');
  
  if (!report) return null;
  
  const isPdf = report.report_type === 'PDF Document';
  const reportDate = new Date(report.created_at);
  const formattedDate = reportDate.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between">
          <div className="flex items-center">
            <div className={`
              h-10 w-10 rounded-lg flex items-center justify-center mr-3
              ${isPdf ? 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400' : 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400'}
            `}>
              {isPdf ? <FileText size={20} /> : <FileImage size={20} />}
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">{report.file_name}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">{formattedDate}</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            onClick={onClose}
            aria-label="Close viewer"
          >
            <X size={20} />
          </Button>
        </div>
        
        <div className="flex border-b border-gray-200 dark:border-gray-800">
          <button
            className={`
              flex-1 py-3 text-sm font-medium border-b-2 transition-colors
              ${tab === 'summary' 
                ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400' 
                : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'}
            `}
            onClick={() => setTab('summary')}
          >
            <BarChart size={16} className="inline mr-2" />
            AI Summary
          </button>
          <button
            className={`
              flex-1 py-3 text-sm font-medium border-b-2 transition-colors
              ${tab === 'full' 
                ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400' 
                : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'}
            `}
            onClick={() => setTab('full')}
          >
            <FileText size={16} className="inline mr-2" />
            Full Text
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6">
          {tab === 'summary' ? (
            <div className="bg-cyan-50 dark:bg-cyan-900/20 p-4 rounded-lg border border-cyan-100 dark:border-cyan-900/30">
              <h4 className="font-medium text-cyan-800 dark:text-cyan-300 mb-2 flex items-center">
                <BarChart size={18} className="mr-2" />
                AI-Generated Summary
              </h4>
              <p className="text-gray-800 dark:text-gray-200 whitespace-pre-line">
                {report.summary || 'No summary available for this report.'}
              </p>
            </div>
          ) : (
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700 font-mono text-sm">
              <pre className="whitespace-pre-wrap text-gray-800 dark:text-gray-200">
                {report.extracted_text || 'No extracted text available for this report.'}
              </pre>
            </div>
          )}
        </div>
        
        <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-800 flex justify-between">
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              leftIcon={<ChevronLeft size={16} />}
              disabled={true} // Would be dynamic in a real app
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              rightIcon={<ChevronRight size={16} />}
              disabled={true} // Would be dynamic in a real app
            >
              Next
            </Button>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            leftIcon={<Download size={16} />}
          >
            Download Original
          </Button>
        </div>
      </div>
    </div>
  );
};