import React from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { 
  FileText, 
  Calendar, 
  BarChart, 
  Download, 
  FileImage,
  Search,
  Loader
} from 'lucide-react';
import { MedicalReport } from '../../lib/supabase';

interface ReportListProps {
  reports: MedicalReport[];
  isLoading: boolean;
  onViewReport: (report: MedicalReport) => void;
}

export const ReportList: React.FC<ReportListProps> = ({ 
  reports, 
  isLoading, 
  onViewReport 
}) => {
  if (isLoading) {
    return (
      <Card className="animate-pulse">
        <div className="p-4 space-y-4">
          <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center space-x-4 py-3 border-t border-gray-200 dark:border-gray-700">
              <div className="h-10 w-10 rounded-lg bg-gray-200 dark:bg-gray-700"></div>
              <div className="flex-1">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
              </div>
              <div className="h-8 w-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
            </div>
          ))}
        </div>
      </Card>
    );
  }

  if (reports.length === 0) {
    return (
      <Card>
        <div className="text-center p-8">
          <FileText size={48} className="mx-auto text-gray-400 mb-3" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">No medical reports yet</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
            Upload your first medical document to get started.
          </p>
        </div>
      </Card>
    );
  }

  return (
    <Card>
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">Your Medical Reports</h3>
          <div className="relative">
            <input
              type="text"
              placeholder="Search reports..."
              className="pl-9 pr-4 py-2 text-sm border border-gray-300 dark:border-gray-700 rounded-md bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
            />
            <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          </div>
        </div>
        
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          {reports.map((report) => {
            const reportDate = new Date(report.created_at);
            const formattedDate = reportDate.toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            });
            
            const isPdf = report.report_type === 'PDF Document';
            
            return (
              <div key={report.id} className="py-3 first:pt-0 last:pb-0">
                <div className="flex items-center">
                  <div className={`
                    h-10 w-10 rounded-lg flex items-center justify-center mr-4
                    ${isPdf ? 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400' : 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400'}
                  `}>
                    {isPdf ? <FileText size={20} /> : <FileImage size={20} />}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-medium text-gray-900 dark:text-white truncate">
                      {report.file_name}
                    </h4>
                    <div className="flex items-center mt-1 text-xs text-gray-500 dark:text-gray-400">
                      <Calendar size={14} className="mr-1" />
                      <span>{formattedDate}</span>
                      <span className="mx-2">•</span>
                      <span>{report.report_type}</span>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-gray-600 dark:text-gray-300"
                      leftIcon={<Download size={16} />}
                      aria-label="Download report"
                    >
                      <span className="sr-only sm:not-sr-only sm:ml-2">Download</span>
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      leftIcon={<Search size={16} />}
                      onClick={() => onViewReport(report)}
                    >
                      <span className="sr-only sm:not-sr-only sm:ml-2">View</span>
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </Card>
  );
};