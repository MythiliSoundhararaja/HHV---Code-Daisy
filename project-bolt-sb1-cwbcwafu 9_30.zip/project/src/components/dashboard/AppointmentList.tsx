import React from 'react';
import { Card } from '../ui/Card';
import { Calendar, Clock, MapPin } from 'lucide-react';
import { Appointment } from '../../lib/supabase';

interface AppointmentListProps {
  appointments: Appointment[];
  isLoading: boolean;
}

export const AppointmentList: React.FC<AppointmentListProps> = ({ 
  appointments, 
  isLoading 
}) => {
  if (isLoading) {
    return (
      <Card className="animate-pulse">
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-start space-x-3">
              <div className="h-10 w-10 rounded-full bg-gray-200 dark:bg-gray-700"></div>
              <div className="flex-1">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    );
  }

  if (appointments.length === 0) {
    return (
      <Card>
        <div className="text-center py-6">
          <Calendar className="h-12 w-12 mx-auto text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900 dark:text-white">No upcoming appointments</h3>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Schedule an appointment to get started.</p>
        </div>
      </Card>
    );
  }

  return (
    <Card>
      <div className="divide-y divide-gray-200 dark:divide-gray-700">
        {appointments.map((appointment) => {
          const appointmentDate = new Date(appointment.appointment_date);
          const formattedDate = appointmentDate.toLocaleDateString('en-US', { 
            weekday: 'short', 
            month: 'short', 
            day: 'numeric' 
          });
          
          return (
            <div key={appointment.id} className="py-4 first:pt-0 last:pb-0">
              <div className="flex items-start">
                <div className={`
                  h-10 w-10 rounded-full flex items-center justify-center mr-3
                  ${appointment.status === 'scheduled' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/40 dark:text-blue-300' : 
                    appointment.status === 'completed' ? 'bg-green-100 text-green-600 dark:bg-green-900/40 dark:text-green-300' : 
                    'bg-yellow-100 text-yellow-600 dark:bg-yellow-900/40 dark:text-yellow-300'}
                `}>
                  <Calendar size={20} />
                </div>
                
                <div className="flex-1">
                  <div className="flex justify-between">
                    <h4 className="text-sm font-medium text-gray-900 dark:text-white">{appointment.doctor_name}</h4>
                    <span className={`
                      inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                      ${appointment.status === 'scheduled' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300' : 
                        appointment.status === 'completed' ? 'bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300' : 
                        'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/40 dark:text-yellow-300'}
                    `}>
                      {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                    </span>
                  </div>
                  
                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">{appointment.purpose}</p>
                  
                  <div className="mt-2 flex items-center text-sm text-gray-500 dark:text-gray-400 space-x-4">
                    <div className="flex items-center">
                      <Calendar size={16} className="mr-1" />
                      <span>{formattedDate}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock size={16} className="mr-1" />
                      <span>{appointment.appointment_time}</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin size={16} className="mr-1" />
                      <span>{appointment.location}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
};