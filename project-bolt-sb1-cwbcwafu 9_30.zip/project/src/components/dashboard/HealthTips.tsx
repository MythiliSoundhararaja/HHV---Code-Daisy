import React, { useState, useEffect } from 'react';
import { Card } from '../ui/Card';
import { Heart, ChevronRight, ChevronLeft } from 'lucide-react';

interface Tip {
  id: number;
  title: string;
  content: string;
  category: string;
}

export const HealthTips: React.FC = () => {
  const [currentTipIndex, setCurrentTipIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  
  // Sample health tips
  const healthTips: Tip[] = [
    {
      id: 1,
      title: 'Stay Hydrated',
      content: 'Drink at least 8 glasses of water daily to maintain proper hydration and support bodily functions.',
      category: 'Nutrition'
    },
    {
      id: 2,
      title: 'Regular Exercise',
      content: 'Aim for at least 30 minutes of moderate physical activity five days a week for better heart health.',
      category: 'Fitness'
    },
    {
      id: 3,
      title: 'Prioritize Sleep',
      content: 'Adults should get 7-9 hours of quality sleep nightly for optimal physical and mental health.',
      category: 'Wellness'
    },
    {
      id: 4,
      title: 'Balanced Diet',
      content: 'Include a variety of fruits, vegetables, whole grains, and lean proteins in your daily meals.',
      category: 'Nutrition'
    },
    {
      id: 5,
      title: 'Stress Management',
      content: 'Practice mindfulness, deep breathing, or meditation to reduce stress and improve mental wellbeing.',
      category: 'Mental Health'
    }
  ];
  
  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);
  
  useEffect(() => {
    // Auto-rotate tips every 10 seconds
    const interval = setInterval(() => {
      setCurrentTipIndex((prevIndex) => (prevIndex + 1) % healthTips.length);
    }, 10000);
    
    return () => clearInterval(interval);
  }, [healthTips.length]);
  
  const navigateTip = (direction: 'next' | 'prev') => {
    if (direction === 'next') {
      setCurrentTipIndex((prevIndex) => (prevIndex + 1) % healthTips.length);
    } else {
      setCurrentTipIndex((prevIndex) => (prevIndex - 1 + healthTips.length) % healthTips.length);
    }
  };
  
  if (isLoading) {
    return (
      <Card className="animate-pulse h-48">
        <div className="flex justify-between mb-4">
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
        </div>
        <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-3"></div>
        <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2"></div>
        <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-5/6"></div>
      </Card>
    );
  }
  
  const currentTip = healthTips[currentTipIndex];
  
  return (
    <Card className="h-48 flex flex-col">
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center">
          <Heart size={18} className="text-red-500 mr-2" />
          <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Daily Health Tip</span>
        </div>
        <span className="text-xs font-medium text-cyan-600 dark:text-cyan-400 bg-cyan-50 dark:bg-cyan-900/30 px-2 py-1 rounded-full">
          {currentTip.category}
        </span>
      </div>
      
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">{currentTip.title}</h3>
      <p className="text-sm text-gray-600 dark:text-gray-300 flex-grow">{currentTip.content}</p>
      
      <div className="flex justify-between items-center mt-4 pt-2 border-t border-gray-100 dark:border-gray-800">
        <button 
          onClick={() => navigateTip('prev')} 
          className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          aria-label="Previous tip"
        >
          <ChevronLeft size={20} className="text-gray-600 dark:text-gray-400" />
        </button>
        
        <div className="flex space-x-1">
          {healthTips.map((_, index) => (
            <span 
              key={index} 
              className={`h-1.5 rounded-full ${index === currentTipIndex ? 'w-4 bg-cyan-500' : 'w-1.5 bg-gray-300 dark:bg-gray-600'}`}
            />
          ))}
        </div>
        
        <button 
          onClick={() => navigateTip('next')} 
          className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          aria-label="Next tip"
        >
          <ChevronRight size={20} className="text-gray-600 dark:text-gray-400" />
        </button>
      </div>
    </Card>
  );
};