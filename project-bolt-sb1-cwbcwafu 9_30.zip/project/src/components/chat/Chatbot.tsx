import React, { useState, useRef, useEffect } from "react";
import { Send, Loader, Bot, User } from "lucide-react";

const API_KEY = "AIzaSyA0C3HemTdK3Gu36D8KpZxdigIiWAbh8iQ"; // Replace with your actual API key

async function fetchResponse(prompt) {
  if (!API_KEY) {
    throw new Error("API Key is missing. Please configure your API key.");
  }

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-pro:generateContent?key=${API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP error! Status: ${response.status}, Message: ${errorText}`);
    }

    const data = await response.json();
    return data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "No response";

  } catch (error) {
    console.error("Error fetching or processing response:", error);
    throw error;
  }
}

function ChatMessage({ message, isBot }) {
  return (
    <div className={`flex w-full mb-4 ${isBot ? "justify-start" : "justify-end"}`}>
      <div className={`flex max-w-3xl ${isBot ? "flex-row" : "flex-row-reverse"}`}>
        <div className={`flex items-center justify-center h-10 w-10 rounded-full ${isBot ? "bg-purple-700" : "bg-blue-600"} mr-3`}>
          {isBot ? <Bot size={20} /> : <User size={20} />}
        </div>
        <div className={`px-4 py-3 rounded-lg ${isBot ? "bg-gray-800 text-white" : "bg-blue-600 text-white"}`}>
          <p className="whitespace-pre-wrap">{message}</p>
        </div>
      </div>
    </div>
  );
}

function GeminiChat() {
  const [input, setInput] = useState("");
  const [conversation, setConversation] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [conversation]);

  const handleSubmit = async () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setInput("");
    setConversation(prev => [...prev, { text: userMessage, isBot: false }]);
    setLoading(true);
    setError(null);

    try {
      const reply = await fetchResponse(userMessage);
      setConversation(prev => [...prev, { text: reply, isBot: true }]);
    } catch (err) {
      setError(err.message || "An unexpected error occurred.");
      setConversation(prev => [...prev, { text: `Error: ${err.message || "An unexpected error occurred."}`, isBot: true, isError: true }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="flex items-center justify-between p-4 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center">
          <div className="bg-purple-700 p-2 rounded-full mr-3">
            <Bot size={24} />
          </div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent">
            Gemini AI Chat
          </h1>
        </div>
      </header>

      {/* Messages area */}
      <div className="flex-grow overflow-auto p-4">
        {conversation.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
            <Bot size={64} className="mb-4 text-purple-500" />
            <h2 className="text-xl font-semibold mb-2">Welcome to Gemini AI Chat</h2>
            <p className="text-center max-w-md">Ask me anything or start a conversation. I'm here to help!</p>
          </div>
        ) : (
          conversation.map((msg, index) => (
            <ChatMessage key={index} message={msg.text} isBot={msg.isBot} isError={msg.isError} />
          ))
        )}
        {loading && (
          <div className="flex w-full mb-4 justify-start">
            <div className="flex max-w-3xl flex-row">
              <div className="flex items-center justify-center h-10 w-10 rounded-full bg-purple-700 mr-3">
                <Bot size={20} />
              </div>
              <div className="px-4 py-3 rounded-lg bg-gray-800 text-white">
                <div className="flex items-center">
                  <Loader className="animate-spin mr-2" size={16} />
                  <span>Thinking...</span>
                </div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input area */}
      <div className="p-4 border-t border-gray-700 bg-gray-800">
        <div className="flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            ref={inputRef}
            placeholder="Message Gemini..."
            className="flex-grow p-3 bg-gray-700 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            disabled={loading}
          />
          <button
            onClick={handleSubmit}
            className={`p-3 rounded-r-lg ${loading || !input.trim() ? 'bg-gray-600' : 'bg-purple-600 hover:bg-purple-700'} transition-colors`}
            disabled={loading || !input.trim()}
          >
            {loading ? <Loader className="animate-spin" size={20} /> : <Send size={20} />}
          </button>
        </div>
      </div>
    </div>
  );
}

export default GeminiChat;