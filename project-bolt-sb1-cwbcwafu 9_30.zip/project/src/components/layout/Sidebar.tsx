import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuthStore } from '../../lib/auth';
import { useThemeStore } from '../../lib/theme';
import { 
  Home, 
  FileText, 
  MessageSquare, 
  Calendar, 
  Settings, 
  LogOut,
  Moon,
  Sun,
  Menu,
  X,
  Stethoscope
} from 'lucide-react';
import { Button } from '../ui/Button';

interface SidebarProps {
  isMobileSidebarOpen: boolean;
  toggleMobileSidebar: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  isMobileSidebarOpen, 
  toggleMobileSidebar 
}) => {
  const { signOut, user } = useAuthStore();
  const { mode, toggleMode } = useThemeStore();
  
  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: <Home size={20} /> },
    { name: 'Medical Reports', path: '/reports', icon: <FileText size={20} /> },
    { name: 'Chat Assistant', path: '/chat', icon: <MessageSquare size={20} /> },
    { name: 'Appointments', path: '/appointments', icon: <Calendar size={20} /> },
    { name: 'Settings', path: '/settings', icon: <Settings size={20} /> },
  ];

  const baseClasses = "fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-gray-900 shadow-lg transition-transform duration-300 transform";
  const mobileClasses = isMobileSidebarOpen ? "translate-x-0" : "-translate-x-full";
  const desktopClasses = "hidden lg:block";

  const sidebarContent = (
    <>
      <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center space-x-2">
          <Stethoscope className="h-8 w-8 text-cyan-600" />
          <span className="text-lg font-semibold text-gray-900 dark:text-white">MediCare</span>
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          className="lg:hidden" 
          onClick={toggleMobileSidebar}
          aria-label="Close sidebar"
        >
          <X size={20} />
        </Button>
      </div>

      <div className="flex flex-col h-[calc(100%-4rem)] justify-between py-4">
        <nav className="space-y-1 px-2">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => `
                flex items-center px-4 py-2.5 text-sm font-medium rounded-md transition-colors
                ${isActive 
                  ? 'bg-cyan-50 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-100' 
                  : 'text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800'}
              `}
              onClick={() => toggleMobileSidebar()}
            >
              <span className="mr-3">{item.icon}</span>
              {item.name}
            </NavLink>
          ))}
        </nav>

        <div className="px-4 space-y-4">
          <Button 
            variant="ghost" 
            size="sm" 
            className="w-full justify-start" 
            onClick={toggleMode}
          >
            {mode === 'light' ? (
              <>
                <Moon size={18} className="mr-2" />
                <span>Dark Mode</span>
              </>
            ) : (
              <>
                <Sun size={18} className="mr-2" />
                <span>Light Mode</span>
              </>
            )}
          </Button>
          
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full justify-start text-red-600 dark:text-red-400 border-red-200 dark:border-red-900/30 hover:bg-red-50 dark:hover:bg-red-900/20" 
            onClick={() => signOut()}
            leftIcon={<LogOut size={18} />}
          >
            Sign Out
          </Button>
          
          {user && (
            <div className="flex items-center space-x-3 border-t border-gray-200 dark:border-gray-800 pt-4 mt-4">
              <div className="w-8 h-8 rounded-full bg-cyan-100 dark:bg-cyan-900 flex items-center justify-center text-cyan-800 dark:text-cyan-200 uppercase">
                {user.email?.charAt(0) || 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                  {user.user_metadata?.full_name || user.email}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );

  return (
    <>
      {/* Mobile sidebar backdrop */}
      {isMobileSidebarOpen && (
        <div 
          className="fixed inset-0 bg-gray-600 bg-opacity-75 z-40 lg:hidden" 
          onClick={toggleMobileSidebar}
        />
      )}
      
      {/* Mobile sidebar */}
      <aside className={`${baseClasses} ${mobileClasses} lg:hidden`}>
        {sidebarContent}
      </aside>
      
      {/* Desktop sidebar */}
      <aside className={`${baseClasses} ${desktopClasses}`}>
        {sidebarContent}
      </aside>
      
      {/* Mobile toggle button */}
      <button
        className="fixed bottom-4 right-4 p-3 rounded-full bg-cyan-600 text-white shadow-lg z-30 lg:hidden"
        onClick={toggleMobileSidebar}
        aria-label="Toggle sidebar"
      >
        <Menu size={24} />
      </button>
    </>
  );
};