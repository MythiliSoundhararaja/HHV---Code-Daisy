import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/Card';
import { HealthTips } from '../components/dashboard/HealthTips';
import { AppointmentList } from '../components/dashboard/AppointmentList';
import Chatbot from '../components/chat/Chatbot';
import { Activity, Clipboard, PlusCircle, Calendar, ArrowRight } from 'lucide-react';
import { useAuthStore } from '../lib/auth';
import { Button } from '../components/ui/Button';
import { supabase, Appointment } from '../lib/supabase';
import { Link } from 'react-router-dom';

export const DashboardPage: React.FC = () => {
  const { user } = useAuthStore();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // For demo purposes, using mock data
  useEffect(() => {
    // Simulating data fetch
    setTimeout(() => {
      const mockAppointments: Appointment[] = [
        {
          id: '1',
          user_id: user?.id || '',
          doctor_name: 'Dr. Sarah Johnson',
          appointment_date: '2025-06-10',
          appointment_time: '10:00 AM',
          purpose: 'Annual physical examination',
          location: 'MediCare Primary Care Center',
          status: 'scheduled',
          created_at: new Date().toISOString(),
        },
        {
          id: '2',
          user_id: user?.id || '',
          doctor_name: 'Dr. Michael Chen',
          appointment_date: '2025-06-20',
          appointment_time: '2:30 PM',
          purpose: 'Follow-up consultation',
          location: 'MediCare Specialty Clinic',
          status: 'scheduled',
          created_at: new Date().toISOString(),
        }
      ];
      
      setAppointments(mockAppointments);
      setIsLoading(false);
    }, 1500);
  }, [user]);
  
  // Get greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {getGreeting()}, {user?.user_metadata?.full_name || 'there'}
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Here's an overview of your health information and upcoming events.
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <Button
            variant="outline"
            leftIcon={<Calendar size={16} />}
            as={Link}
            to="/appointments"
          >
            Schedule Appointment
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-br from-cyan-600 to-cyan-700 text-white">
          <div className="p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Health Stats</h3>
              <Activity size={20} />
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-cyan-100">Last Check-up</p>
                <p className="font-semibold">Mar 15, 2025</p>
              </div>
              <div>
                <p className="text-xs text-cyan-100">Next Check-up</p>
                <p className="font-semibold">Sep 15, 2025</p>
              </div>
              <div>
                <p className="text-xs text-cyan-100">Medications</p>
                <p className="font-semibold">2 Active</p>
              </div>
              <div>
                <p className="text-xs text-cyan-100">Allergies</p>
                <p className="font-semibold">None</p>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-cyan-500">
              <Link 
                to="/reports" 
                className="text-sm flex items-center text-cyan-100 hover:text-white transition-colors"
              >
                View medical history
                <ArrowRight size={16} className="ml-1" />
              </Link>
            </div>
          </div>
        </Card>
        
        <Card className="md:col-span-2">
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Activity</h3>
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-cyan-600 dark:text-cyan-400"
                as={Link}
                to="/reports"
              >
                View All
              </Button>
            </div>
            
            <div className="space-y-4">
              <div className="flex">
                <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center text-blue-600 dark:text-blue-400">
                  <Calendar size={20} />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    Appointment scheduled with Dr. Sarah Johnson
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Jun 10, 2025 at 10:00 AM
                  </p>
                </div>
              </div>
              
              <div className="flex">
                <div className="flex-shrink-0 h-10 w-10 rounded-full bg-green-100 dark:bg-green-900/40 flex items-center justify-center text-green-600 dark:text-green-400">
                  <Clipboard size={20} />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    Blood test results uploaded
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    May 28, 2025
                  </p>
                </div>
              </div>
              
              <div className="flex">
                <div className="flex-shrink-0 h-10 w-10 rounded-full bg-purple-100 dark:bg-purple-900/40 flex items-center justify-center text-purple-600 dark:text-purple-400">
                  <PlusCircle size={20} />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    Prescription renewed
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    May 20, 2025
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Upcoming Appointments
          </h2>
          <AppointmentList 
            appointments={appointments} 
            isLoading={isLoading} 
          />
        </div>
        
        <div className="space-y-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Daily Health Tips
          </h2>
          <HealthTips />
        </div>
      </div>
      
      <div className="space-y-6">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
          Healthcare Assistant
        </h2>
        <Chatbot />
      </div>
    </div>
  );
};