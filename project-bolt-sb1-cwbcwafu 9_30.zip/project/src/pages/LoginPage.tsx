import React, { useState, useEffect } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { AuthForm } from '../components/auth/AuthForm';
import { useAuthStore } from '../lib/auth';
import { useThemeStore } from '../lib/theme';
import { Stethoscope, Moon, Sun } from 'lucide-react';

export const LoginPage: React.FC = () => {
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const { user, loading } = useAuthStore();
  const { mode, toggleMode } = useThemeStore();
  
  // Apply dark mode to document
  useEffect(() => {
    if (mode === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [mode]);
  
  if (user) {
    return <Navigate to="/dashboard" replace />;
  }
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8 transition-colors duration-200">
      <button 
        className="absolute top-4 right-4 p-2 rounded-full bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300"
        onClick={toggleMode}
        aria-label={mode === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
      >
        {mode === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
      </button>
      
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <div className="h-14 w-14 rounded-full bg-cyan-600 dark:bg-cyan-800 flex items-center justify-center">
            <Stethoscope className="h-8 w-8 text-white" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900 dark:text-white">
          MediCare
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600 dark:text-gray-400">
          Your personalized healthcare assistant
        </p>
      </div>
      
      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white dark:bg-gray-800 py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <div className="flex border-b border-gray-200 dark:border-gray-700 mb-6">
            <button
              className={`
                flex-1 py-2 text-sm font-medium border-b-2 transition-colors
                ${authMode === 'login' 
                  ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400' 
                  : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'}
              `}
              onClick={() => setAuthMode('login')}
            >
              Sign In
            </button>
            <button
              className={`
                flex-1 py-2 text-sm font-medium border-b-2 transition-colors
                ${authMode === 'signup' 
                  ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400' 
                  : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'}
              `}
              onClick={() => setAuthMode('signup')}
            >
              Create Account
            </button>
          </div>
          
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-cyan-600"></div>
            </div>
          ) : (
            <AuthForm mode={authMode} />
          )}
          
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300 dark:border-gray-600"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400">
                  {authMode === 'login' ? 'New to MediCare?' : 'Already have an account?'}
                </span>
              </div>
            </div>
            
            <div className="mt-6 text-center">
              <button
                className="text-sm font-medium text-cyan-600 hover:text-cyan-500 dark:text-cyan-400 dark:hover:text-cyan-300"
                onClick={() => setAuthMode(authMode === 'login' ? 'signup' : 'login')}
              >
                {authMode === 'login' ? 'Create a new account' : 'Sign in to your account'}
              </button>
            </div>
          </div>
        </div>
        
        <p className="mt-6 text-center text-xs text-gray-600 dark:text-gray-400">
          &copy; {new Date().getFullYear()} MediCare. All rights reserved.
        </p>
      </div>
    </div>
  );
};