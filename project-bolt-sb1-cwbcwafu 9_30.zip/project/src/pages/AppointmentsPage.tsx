import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Calendar, Clock, Plus, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { useAuthStore } from '../lib/auth';
import { AppointmentList } from '../components/dashboard/AppointmentList';
import { Appointment } from '../lib/supabase';
import { toast } from 'react-hot-toast';

export const AppointmentsPage: React.FC = () => {
  const { user } = useAuthStore();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAppointmentForm, setShowAppointmentForm] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const [formData, setFormData] = useState({
    doctorName: '',
    purpose: '',
    date: '',
    time: '',
    
  });
  
  // Mock data for demonstration
  useEffect(() => {
    setTimeout(() => {
      const mockAppointments: Appointment[] = [
        {
          id: '1',
          user_id: user?.id || '',
          doctor_name: 'Dr. Sarah Johnson',
          appointment_date: '2025-06-10',
          appointment_time: '10:00 AM',
          purpose: 'Annual physical examination',
          
          status: 'scheduled',
          created_at: new Date().toISOString(),
        },
        {
          id: '2',
          user_id: user?.id || '',
          doctor_name: 'Dr. Michael Chen',
          appointment_date: '2025-06-20',
          appointment_time: '2:30 PM',
          purpose: 'Follow-up consultation',
          
          status: 'scheduled',
          created_at: new Date().toISOString(),
        },
        {
          id: '3',
          user_id: user?.id || '',
          doctor_name: 'Dr. Emily Rodriguez',
          appointment_date: '2025-05-15',
          appointment_time: '9:15 AM',
          purpose: 'Vaccination',
          
          status: 'completed',
          created_at: new Date('2025-05-10').toISOString(),
        }
      ];
      
      setAppointments(mockAppointments);
      setIsLoading(false);
    }, 1000);
  }, [user]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.doctorName || !formData.purpose || !formData.date || !formData.time || !formData.location) {
      toast.error('Please fill in all fields');
      return;
    }
    
    // Create new appointment
    const newAppointment: Appointment = {
      id: Date.now().toString(),
      user_id: user?.id || '',
      doctor_name: formData.doctorName,
      appointment_date: formData.date,
      appointment_time: formData.time,
      purpose: formData.purpose,
      
      status: 'scheduled',
      created_at: new Date().toISOString(),
    };
    
    // Add to list
    setAppointments([...appointments, newAppointment]);
    
    // Reset form
    setFormData({
      doctorName: '',
      purpose: '',
      date: '',
      time: '',
      
    });
    
    setShowAppointmentForm(false);
    toast.success('Appointment scheduled successfully!');
  };
  
  // Generate calendar days for the month
  const generateCalendarDays = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();
    
    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add the days of the month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i);
    }
    
    return days;
  };
  
  const navigateMonth = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    if (direction === 'prev') {
      newDate.setMonth(newDate.getMonth() - 1);
    } else {
      newDate.setMonth(newDate.getMonth() + 1);
    }
    setCurrentDate(newDate);
  };
  
  const formatMonthYear = () => {
    return currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  };
  
  const getDayClassName = (day: number | null) => {
    if (day === null) return 'invisible';
    
    // Today
    const today = new Date();
    const isToday = day === today.getDate() && 
      currentDate.getMonth() === today.getMonth() && 
      currentDate.getYear() === today.getYear();
    
    // Has appointment
    const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const hasAppointment = appointments.some(a => a.appointment_date === dateStr);
    
    let className = "w-10 h-10 rounded-full flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer";
    
    if (isToday) {
      className += " bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300 font-semibold";
    }
    
    if (hasAppointment) {
      className += " border-2 border-cyan-500";
    }
    
    return className;
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Appointments
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Schedule and manage your healthcare appointments.
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <Button
            leftIcon={<Plus size={16} />}
            onClick={() => setShowAppointmentForm(!showAppointmentForm)}
          >
            {showAppointmentForm ? 'Cancel' : 'Schedule Appointment'}
          </Button>
        </div>
      </div>
      
      {showAppointmentForm && (
        <Card>
          <form onSubmit={handleSubmit} className="p-6">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
              Schedule New Appointment
            </h3>
            
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <Input
                label="Doctor's Name"
                name="doctorName"
                value={formData.doctorName}
                onChange={handleInputChange}
                placeholder="Dr. Smith"
                fullWidth
              />
              
              <Input
                label="Purpose"
                name="purpose"
                value={formData.purpose}
                onChange={handleInputChange}
                placeholder="Annual check-up, consultation, etc."
                fullWidth
              />
              
              <Input
                label="Date"
                name="date"
                type="date"
                value={formData.date}
                onChange={handleInputChange}
                fullWidth
                leftIcon={<Calendar size={18} className="text-gray-500" />}
              />
              
              <Input
                label="Time"
                name="time"
                type="time"
                value={formData.time}
                onChange={handleInputChange}
                fullWidth
                leftIcon={<Clock size={18} className="text-gray-500" />}
              />
              
              
            </div>
            
            <div className="mt-6 flex justify-end space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowAppointmentForm(false)}
                leftIcon={<X size={16} />}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                leftIcon={<Calendar size={16} />}
              >
                Schedule Appointment
              </Button>
            </div>
          </form>
        </Card>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <div className="p-6">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Your Appointments
              </h3>
              <AppointmentList 
                appointments={appointments} 
                isLoading={isLoading} 
              />
            </div>
          </Card>
        </div>
        
        <div>
          <Card>
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                  Calendar
                </h3>
                <div className="flex space-x-1">
                  <button
                    className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800"
                    onClick={() => navigateMonth('prev')}
                    aria-label="Previous month"
                  >
                    <ChevronLeft size={18} className="text-gray-600 dark:text-gray-400" />
                  </button>
                  <button
                    className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800"
                    onClick={() => navigateMonth('next')}
                    aria-label="Next month"
                  >
                    <ChevronRight size={18} className="text-gray-600 dark:text-gray-400" />
                  </button>
                </div>
              </div>
              
              <div className="text-center font-medium mb-4 text-gray-800 dark:text-gray-200">
                {formatMonthYear()}
              </div>
              
              <div className="grid grid-cols-7 gap-1 text-center mb-2">
                {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((day) => (
                  <div key={day} className="text-xs text-gray-500 dark:text-gray-400">
                    {day}
                  </div>
                ))}
              </div>
              
              <div className="grid grid-cols-7 gap-1 text-center">
                {generateCalendarDays().map((day, i) => (
                  <div key={i} className="flex justify-center py-1">
                    <div 
                      className={getDayClassName(day)}
                      onClick={() => {
                        if (day !== null) {
                          const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                          setFormData({
                            ...formData,
                            date: dateStr
                          });
                          setShowAppointmentForm(true);
                        }
                      }}
                    >
                      {day}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="w-4 h-4 rounded-full border-2 border-cyan-500"></div>
                  <span className="text-xs text-gray-600 dark:text-gray-400">Appointment Day</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 rounded-full bg-cyan-100 dark:bg-cyan-900/40"></div>
                  <span className="text-xs text-gray-600 dark:text-gray-400">Today</span>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};