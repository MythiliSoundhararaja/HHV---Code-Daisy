import React from 'react';
import Chatbot from '../components/chat/Chatbot';

export const ChatPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Healthcare Assistant
        </h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Chat with your AI healthcare assistant for medical advice, appointment scheduling, and more.
        </p>
      </div>
      
      <Chatbot fullPage />
    </div>
  );
};