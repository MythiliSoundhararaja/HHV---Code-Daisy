import React, { useState, useEffect } from 'react';
import { DocumentUploader } from '../components/reports/DocumentUploader';
import { ReportList } from '../components/reports/ReportList';
import { ReportViewer } from '../components/reports/ReportViewer';
import { useAuthStore } from '../lib/auth';
import { Button } from '../components/ui/Button';
import { Upload, Filter } from 'lucide-react';
import { MedicalReport } from '../lib/supabase';

export const ReportsPage: React.FC = () => {
  const { user } = useAuthStore();
  const [showUploader, setShowUploader] = useState(false);
  const [selectedReport, setSelectedReport] = useState<MedicalReport | null>(null);
  const [reports, setReports] = useState<MedicalReport[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Mock data for demonstration
  useEffect(() => {
    if (user) {
      setTimeout(() => {
        const mockReports: MedicalReport[] = [
          {
            id: '1',
            user_id: user.id,
            file_name: 'Annual Physical Exam Results.pdf',
            file_url: '/mock-url/exam.pdf',
            extracted_text: 'Patient: John Doe\nDate: 2025-03-15\nDoctor: Dr. Sarah Johnson\n\nVital Signs:\nBlood Pressure: 120/80 mmHg\nHeart Rate: 72 bpm\nTemperature: 98.6°F\nRespiratory Rate: 16 breaths/min\n\nGeneral Appearance: Patient appears well, in no acute distress.\n\nAssessment: Overall good health. Maintains normal weight and BP. Regular exercise is encouraged.\n\nPlan: Annual follow-up recommended. Continue current medications.',
            summary: 'Summary: Annual physical examination shows normal vital signs and good overall health. Patient is maintaining normal weight and blood pressure. Regular exercise is encouraged. Annual follow-up recommended with continuation of current medications.',
            report_date: '2025-03-15',
            report_type: 'PDF Document',
            created_at: '2025-03-16T10:30:00Z',
          },
          {
            id: '2',
            user_id: user.id,
            file_name: 'Blood Test Results.pdf',
            file_url: '/mock-url/blood-test.pdf',
            extracted_text: 'Patient: John Doe\nDate: 2025-02-10\nTest: Comprehensive Metabolic Panel\n\nResults:\nGlucose: 92 mg/dL (Reference: 70-99 mg/dL)\nBUN: 15 mg/dL (Reference: 7-20 mg/dL)\nCreatinine: 0.9 mg/dL (Reference: 0.6-1.2 mg/dL)\nSodium: 140 mEq/L (Reference: 136-145 mEq/L)\nPotassium: 4.0 mEq/L (Reference: 3.5-5.1 mEq/L)\nChloride: 101 mEq/L (Reference: 98-107 mEq/L)\nCalcium: 9.5 mg/dL (Reference: 8.5-10.5 mg/dL)\n\nInterpretation: All values within normal range.\n\nRecommendation: Continue current health maintenance plan.',
            summary: 'Summary: Comprehensive Metabolic Panel shows all values within normal range. Blood glucose, kidney function (BUN and creatinine), and electrolytes (sodium, potassium, chloride, calcium) are all normal. No abnormalities detected. Recommendation is to continue current health maintenance plan.',
            report_date: '2025-02-10',
            report_type: 'PDF Document',
            created_at: '2025-02-11T14:15:00Z',
          },
          {
            id: '3',
            user_id: user.id,
            file_name: 'Chest X-Ray.jpg',
            file_url: '/mock-url/chest-xray.jpg',
            extracted_text: 'Patient: John Doe\nDate: 2025-01-05\nProcedure: Chest X-Ray (PA and Lateral)\n\nClinical Indication: Routine health check\n\nFindings: Heart size and contour are normal. Lungs are clear without infiltrates or effusions. No pneumothorax or pleural disease. No acute cardiopulmonary process identified.\n\nImpression: Normal chest radiograph.',
            summary: 'Summary: Chest X-Ray performed for routine health check shows normal findings. Heart size and contour are normal. Lungs are clear without any infiltrates or effusions. No pneumothorax or pleural disease detected. Overall assessment indicates a normal chest radiograph with no acute cardiopulmonary process identified.',
            report_date: '2025-01-05',
            report_type: 'Image',
            created_at: '2025-01-06T09:45:00Z',
          },
        ];
        
        setReports(mockReports);
        setIsLoading(false);
      }, 1500);
    }
  }, [user]);
  
  const handleViewReport = (report: MedicalReport) => {
    setSelectedReport(report);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Medical Reports
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            View, upload, and manage your medical documents and test results.
          </p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3">
          <Button
            variant="outline"
            leftIcon={<Filter size={16} />}
          >
            Filter
          </Button>
          
          <Button
            leftIcon={<Upload size={16} />}
            onClick={() => setShowUploader(!showUploader)}
          >
            {showUploader ? 'Hide Uploader' : 'Upload Document'}
          </Button>
        </div>
      </div>
      
      {showUploader && (
        <DocumentUploader />
      )}
      
      <ReportList
        reports={reports}
        isLoading={isLoading}
        onViewReport={handleViewReport}
      />
      
      {selectedReport && (
        <ReportViewer
          report={selectedReport}
          onClose={() => setSelectedReport(null)}
        />
      )}
    </div>
  );
};