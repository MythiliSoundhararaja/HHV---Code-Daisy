import React from 'react';
import { Button } from '../components/ui/Button';
import { Link } from 'react-router-dom';
import { Home, ArrowLeft } from 'lucide-react';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white dark:bg-gray-800 py-8 px-4 shadow sm:rounded-lg sm:px-10 text-center">
          <h2 className="text-6xl font-bold text-gray-900 dark:text-white mb-2">404</h2>
          <h3 className="text-2xl font-semibold text-gray-700 dark:text-gray-300 mb-4">Page Not Found</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-6">
            The page you're looking for doesn't exist or has been moved.
          </p>
          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3 justify-center">
            <Button
              variant="outline"
              as={Link}
              to="/dashboard"
              leftIcon={<Home size={18} />}
            >
              Go to Dashboard
            </Button>
            <Button
              as={Link}
              to="/dashboard"
              leftIcon={<ArrowLeft size={18} />}
            >
              Go Back
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};