import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { useAuthStore } from '../lib/auth';
import { Moon, Sun, Bell, Lock, User, Shield, LogOut } from 'lucide-react';
import { useThemeStore } from '../lib/theme';
import { toast } from 'react-hot-toast';

export const SettingsPage: React.FC = () => {
  const { user, signOut } = useAuthStore();
  const { mode, toggleMode } = useThemeStore();
  
  const [profileData, setProfileData] = useState({
    fullName: user?.user_metadata?.full_name || '',
    email: user?.email || '',
    phone: '+1 (555) 123-4567', // Mock data
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    appointmentReminders: true,
    medicationReminders: true,
    reportUpdates: true,
  });
  
  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileData({
      ...profileData,
      [name]: value,
    });
  };
  
  const handleNotificationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setNotificationSettings({
      ...notificationSettings,
      [name]: checked,
    });
  };
  
  const handleSaveProfile = () => {
    // In a real app, this would update the user profile in Supabase
    toast.success('Profile updated successfully!');
  };
  
  const handleSaveNotifications = () => {
    toast.success('Notification settings updated!');
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Settings
        </h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Manage your account settings and preferences.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <div className="p-6">
              <div className="flex items-center space-x-3 mb-6">
                <User size={24} className="text-cyan-600 dark:text-cyan-400" />
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Profile Information</h2>
              </div>
              
              <div className="space-y-4">
                <Input
                  label="Full Name"
                  name="fullName"
                  value={profileData.fullName}
                  onChange={handleProfileChange}
                  fullWidth
                />
                
                <Input
                  label="Email Address"
                  name="email"
                  value={profileData.email}
                  onChange={handleProfileChange}
                  disabled
                  helperText="Email cannot be changed"
                  fullWidth
                />
                
                <Input
                  label="Phone Number"
                  name="phone"
                  value={profileData.phone}
                  onChange={handleProfileChange}
                  fullWidth
                />
                
                <Button
                  onClick={handleSaveProfile}
                  className="mt-2"
                >
                  Save Changes
                </Button>
              </div>
            </div>
          </Card>
          
          <Card>
            <div className="p-6">
              <div className="flex items-center space-x-3 mb-6">
                <Bell size={24} className="text-cyan-600 dark:text-cyan-400" />
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Notification Settings</h2>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="flex items-center cursor-pointer">
                    <div className="ml-3">
                      <span className="text-sm font-medium text-gray-900 dark:text-white">Email Notifications</span>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Receive email updates about your account</p>
                    </div>
                  </label>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      name="emailNotifications"
                      checked={notificationSettings.emailNotifications}
                      onChange={handleNotificationChange}
                      className="sr-only peer" 
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-cyan-300 dark:peer-focus:ring-cyan-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-cyan-600"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <label className="flex items-center cursor-pointer">
                    <div className="ml-3">
                      <span className="text-sm font-medium text-gray-900 dark:text-white">Appointment Reminders</span>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Get notified about upcoming appointments</p>
                    </div>
                  </label>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      name="appointmentReminders"
                      checked={notificationSettings.appointmentReminders}
                      onChange={handleNotificationChange}
                      className="sr-only peer" 
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-cyan-300 dark:peer-focus:ring-cyan-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-cyan-600"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <label className="flex items-center cursor-pointer">
                    <div className="ml-3">
                      <span className="text-sm font-medium text-gray-900 dark:text-white">Medication Reminders</span>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Get reminded to take your medications</p>
                    </div>
                  </label>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      name="medicationReminders"
                      checked={notificationSettings.medicationReminders}
                      onChange={handleNotificationChange}
                      className="sr-only peer" 
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-cyan-300 dark:peer-focus:ring-cyan-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-cyan-600"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <label className="flex items-center cursor-pointer">
                    <div className="ml-3">
                      <span className="text-sm font-medium text-gray-900 dark:text-white">Report Updates</span>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Get notified when new reports are available</p>
                    </div>
                  </label>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      name="reportUpdates"
                      checked={notificationSettings.reportUpdates}
                      onChange={handleNotificationChange}
                      className="sr-only peer" 
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-cyan-300 dark:peer-focus:ring-cyan-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-cyan-600"></div>
                  </label>
                </div>
                
                <Button
                  onClick={handleSaveNotifications}
                  className="mt-2"
                >
                  Save Preferences
                </Button>
              </div>
            </div>
          </Card>
        </div>
        
        <div className="space-y-6">
          <Card>
            <div className="p-6">
              <div className="flex items-center space-x-3 mb-6">
                <Shield size={24} className="text-cyan-600 dark:text-cyan-400" />
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Account Security</h2>
              </div>
              
              <div className="space-y-4">
                <Button
                  variant="outline"
                  fullWidth
                  leftIcon={<Lock size={16} />}
                  onClick={() => toast.success('Password reset email sent!')}
                >
                  Change Password
                </Button>
                
                <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                    Two-factor authentication adds an extra layer of security to your account.
                  </p>
                  
                  <Button
                    variant="outline"
                    fullWidth
                    onClick={() => toast.success('Two-factor authentication enabled!')}
                  >
                    Enable Two-Factor Auth
                  </Button>
                </div>
              </div>
            </div>
          </Card>
          
          <Card>
            <div className="p-6">
              <div className="flex items-center space-x-3 mb-6">
                {mode === 'dark' ? 
                  <Moon size={24} className="text-cyan-600 dark:text-cyan-400" /> : 
                  <Sun size={24} className="text-cyan-600 dark:text-cyan-400" />
                }
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Appearance</h2>
              </div>
              
              <div className="space-y-4">
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Switch between light and dark mode for your comfort.
                </p>
                
                <Button
                  variant="outline"
                  fullWidth
                  leftIcon={mode === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
                  onClick={toggleMode}
                >
                  Switch to {mode === 'dark' ? 'Light' : 'Dark'} Mode
                </Button>
              </div>
            </div>
          </Card>
          
          <Card>
            <div className="p-6">
              <div className="flex items-center space-x-3 mb-6">
                <LogOut size={24} className="text-red-500" />
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Sign Out</h2>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                  Sign out of your account on this device.
                </p>
                
                <Button
                  variant="outline"
                  fullWidth
                  className="border-red-300 text-red-600 hover:bg-red-50 dark:border-red-900/30 dark:text-red-400 dark:hover:bg-red-900/20"
                  leftIcon={<LogOut size={16} />}
                  onClick={() => signOut()}
                >
                  Sign Out
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};