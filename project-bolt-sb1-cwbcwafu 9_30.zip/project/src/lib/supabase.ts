import { createClient } from '@supabase/supabase-js';

// Environment variables are automatically injected by Vite
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Supabase credentials missing. Please check your environment variables.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Types for the database schema
export type Profile = {
  id: string;
  email: string;
  full_name: string;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
};

export type Appointment = {
  id: string;
  user_id: string;
  doctor_name: string;
  appointment_date: string;
  appointment_time: string;
  purpose: string;
  location: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  created_at: string;
};

export type MedicalReport = {
  id: string;
  user_id: string;
  file_name: string;
  file_url: string;
  extracted_text: string | null;
  summary: string | null;
  report_date: string | null;
  report_type: string;
  created_at: string;
};

export type ChatMessage = {
  id: string;
  user_id: string;
  message: string;
  response: string | null;
  is_ai: boolean;
  created_at: string;
};