import { create } from 'zustand';
import { supabase } from './supabase';
import { User } from '@supabase/supabase-js';
import { toast } from 'react-hot-toast';

type AuthState = {
  user: User | null;
  loading: boolean;
  error: string | null;
  signUp: (email: string, password: string, fullName: string) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  loadUser: () => Promise<void>;
};

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,
  error: null,
  
  signUp: async (email: string, password: string, fullName: string) => {
    try {
      set({ loading: true, error: null });
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
          },
        },
      });

      if (error) throw error;
      
      if (data.user) {
        // Create or update user profile
        const { error: profileError } = await supabase
          .from('profiles')
          .upsert({
            id: data.user.id,
            email,
            full_name: fullName,
            updated_at: new Date().toISOString(),
          });

        if (profileError) throw profileError;
      }

      toast.success('Account created! Please check your email for confirmation.');
      set({ loading: false });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      toast.error(errorMessage);
      set({ error: errorMessage, loading: false });
    }
  },
  
  signIn: async (email: string, password: string) => {
    try {
      set({ loading: true, error: null });
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      
      if (error) {
        if (error.message === 'Invalid login credentials') {
          throw new Error(
            'Invalid email or password. Please check your credentials and try again. ' +
            'If you haven\'t confirmed your email, please check your inbox for the confirmation link.'
          );
        }
        throw error;
      }
      
      set({ user: data.user, loading: false });
      toast.success('Successfully signed in!');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      toast.error(errorMessage);
      set({ error: errorMessage, loading: false });
    }
  },
  
  signOut: async () => {
    try {
      set({ loading: true });
      const { error } = await supabase.auth.signOut();
      
      if (error) throw error;
      
      set({ user: null, loading: false });
      toast.success('Successfully signed out');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      toast.error(errorMessage);
      set({ error: errorMessage, loading: false });
    }
  },
  
  loadUser: async () => {
    try {
      set({ loading: true });
      const { data, error } = await supabase.auth.getUser();
      
      if (error) throw error;
      
      set({ user: data.user, loading: false });
    } catch (error) {
      set({ user: null, loading: false });
    }
  },
}));